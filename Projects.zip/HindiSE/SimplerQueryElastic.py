from elasticsearch import Elasticsearch
from json import dumps, loads
import urllib2


def main():
    strInput = raw_input("Enter search query here: ")
    sortedTitle, dictionary = find(strInput)
    queryList = strInput.split(" ")
    morph(queryList)

    print "\n\nThe top results:\n"
    counter = 0
    for i in range(0, len(dictionary)):
        print "Result (" + str(counter + 1) + "):"
        print "Id: " + dictionary[sortedTitle[i]]['Id']
        print "Title: " + sortedTitle[i]
        print "Score: " + str(dictionary[sortedTitle[i]]['Score'])
        print "Image: " + dictionary[sortedTitle[i]]['Image']
        print "URL: " + dictionary[sortedTitle[i]]['URL']
        print "Summary: " + dictionary[sortedTitle[i]]['Summary']
        counter += 1
        print "\n"


def find(query):
    es = Elasticsearch()
    searchDoc = {
        "size": 20,
        "query": {
            "dis_max": {
                "queries": [
                    {
                        "match": {
                            "data.source.title": {
                                "query": query,
                                "boost": 2
                            }
                        }
                    },
                    {
                        "match": {
                            "data.source.summary": {
                                "query": query,
                                "boost": 1.5
                            }
                        }
                    },
                    {
                        "match": {
                            "data.source.body": query
                        }
                    }
                ]
            }
        }
    }

    dictionary = {}

    result = es.search(index="jagrantest", doc_type='doc', body=dumps(searchDoc))
    for data in result['hits']['hits']:
        title = data['_source']['data']['source']['title']
        dictionary[title] = {}
        dictionary[title]['URL'] = data['_source']['url']
        dictionary[title]['Summary'] = data['_source']['data']['source']['summary']
        dictionary[title]['Score'] = data['_score']
        dictionary[title]['Id'] = data['_id']
        dictionary[title]['Image'] = data['_source']['data']['source']['twitter']['image']

    newDict = {}
    for key, value in dictionary.items():
        newDict[key] = value['Score']

    sortedTitle = sorted(newDict, key=newDict.get, reverse=True)

    return sortedTitle, dictionary


def morph(queryList):
    link = "https://www.bing.com/translator/api/Dictionary/Lookup?from=hi&to=en&text="
    for query in queryList:
        newStr = link + str(query)
        tempStr = "/translator/api/Dictionary/Lookup?from=hi&to=en&text=" + str(query)
        hdrs = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "accept-encoding": "gzip, deflate, lzma, sdch",
            "accept-language": "en-US,en;q=0.8",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36 OPR/39.0.2256.71",
            "x-opera-main": newStr,
            "x-opera-requesttype": "main-frame"
        }
        resp = urllib2.Request(newStr, headers=hdrs)
        try:
            response = urllib2.urlopen(resp)
            data = loads(response.read())
            posTag = data['items'][0][0]['posTag']
            if posTag:
                print query + "Pos Tag: " + posTag
        except urllib2.HTTPError, e:
            print e.fp.read()

if __name__ == "__main__":
    main()
