from flask import Flask, render_template, request
import os
from SimplerQueryElastic import find

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    errors = []
    results = {}
    searchDone = False
    if request.method == "POST":
        searchDone = False
        # noinspection PyBroadException
        try:
            userInput = request.form['userInput']
            print userInput
        except:
            errors.append("Error")
            return render_template('index.html', errors=errors)
        if userInput:
            itemValues, dictionary = find(userInput)
            length = len(itemValues)
            if length > 10:
                length = 10
            elif length is 10:
                length = 9
            newDict = {}
            for i in range(0, length):
                newDict[i] = {}
                newDict[i]['Id'] = i + 1
                newDict[i]['Title'] = itemValues[i]
                newDict[i]['URL'] = dictionary[itemValues[i]]['URL']
                newDict[i]['Summary'] = dictionary[itemValues[i]]['Summary']
                newDict[i]['Image'] = dictionary[itemValues[i]]['Image']
            results = newDict
            searchDone = True
    return render_template('index.html', errors=errors, results=results, searchDone=searchDone)

app.run()
