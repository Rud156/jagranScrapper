from pymongo import MongoClient
from elasticsearch import Elasticsearch
from json import dumps

client = MongoClient('localhost:27017')
db = client.JagranTest
es = Elasticsearch()
es.indices.delete(index='jagrantest', ignore=[404, 400])
data = db.Contents.find()
total = ""
for i in range(0, data.count()):
    body = ""
    author = ""
    for bod in data[i]['data']['source']['body']:
        body += bod.strip()
        body += " "
    for auth in data[i]['data']['author']:
        author += auth
        auth += " "

    twitterDesc = ""
    twitterTitle = ""
    twitterCard = ""
    summary = ""
    twitterImage = ""
    length = len(data[i]['data']['source']['twitter']['description'])
    if length > 0:
        twitterDesc = data[i]['data']['source']['twitter']['description'][0]
    length = len(data[i]['data']['source']['twitter']['title'])
    if length > 0:
        twitterTitle = data[i]['data']['source']['twitter']['title'][0]
    length = len(data[i]['data']['source']['twitter']['card'])
    if length > 0:
        twitterCard = data[i]['data']['source']['twitter']['card'][0]
    length = len(data[i]['data']['source']['summary'])
    if length > 0:
        summary = data[i]['data']['source']['summary'][0]
    length = len(data[i]['data']['source']['twitter']['image'])
    if length > 0:
        twitterImage = data[i]['data']['source']['twitter']['image'][0]
    dataSet = {
        'url': data[i]['url'][0],
        'data': {
            'alternate_url': data[i]['data']['alternate_urls'],
            'source': {
                'meta_description': data[i]['data']['source']['meta_description'][0],
                'body': body,
                'meta_title': data[i]['data']['source']['meta_title'][0],
                'meta_keywords': data[i]['data']['source']['meta_keywords'][0].strip(),
                'title': data[i]['data']['source']['title'][0],
                'lastModified': data[i]['data']['source']['lastModified'][0],
                'summary': summary,
                'author': author,
                'twitter': {
                    'description': twitterDesc,
                    'title': twitterTitle,
                    'image': twitterImage,
                    'creator_id': data[i]['data']['source']['twitter']['creator_id'][0],
                    'creator_username': data[i]['data']['source']['twitter']['creator_username'][0],
                    'card': twitterCard
                }
            }
        }
    }
    doc = {
        'index': {
            '_index': 'jagrantest',
            '_id': str(i + 1),
            '_type': 'doc'
        }
    }
    total += dumps(doc) + "\n" + dumps(dataSet) + "\n"

    # total += dumps(doc) + '\n' + dumps(dataSet) + '\n'
    # es.index(index='jagrantest', doc_type='doc', id=i, body=dataSet)

    print "Added " + str(i + 1)
    if (i % 200) is 0:
        es.bulk(body=total)
        print "Set Data Added"
        total = ""

# print total
es.bulk(body=total)
total = ""
print "Data Added To Elastic Search"
