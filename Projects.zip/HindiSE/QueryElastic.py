from elasticsearch import Elasticsearch
from json import dumps


def check(value):
    es = Elasticsearch()
    tempList = value.split(" ")
    length = len(tempList)
    queryList = []
    for i in range(0, length):
        for j in range(i, length):
            newStr = ""
            for k in range(i, j + 1):
                newStr += tempList[k]
                newStr += " "
            queryList.append(newStr.strip())

    dictionary = {}
    for i in range(0, 3):
        checkRes = ""
        if i is 0:
            checkRes = 'data.source.title'
        elif i is 1:
            checkRes = 'data.source.summary'
        elif i is 2:
            checkRes = 'data.source.body'
        for que in queryList:
            searchDoc = {
                'size': 10,
                'query': {
                    'match': {
                        checkRes: que
                    }
                }
            }
            result = es.search(index="jagrantest", doc_type='doc', body=dumps(searchDoc))
            for data in result['hits']['hits']:
                title = data['_source']['data']['source']['title']
                if title in dictionary:
                    dictionary[title]['Count'] += 1
                    curScore = dictionary[title]['Score']
                    if data['_score'] > curScore:
                        dictionary[title]['Score'] = data['_score']
                else:
                    dictionary[title] = {}
                    dictionary[title]['Count'] = 0
                    dictionary[title]['URL'] = data['_source']['url']
                    dictionary[title]['Summary'] = data['_source']['data']['source']['summary']
                    dictionary[title]['Score'] = data['_score']
                    dictionary[title]['Id'] = data['_id']
                    dictionary[title]['Image'] = data['_source']['data']['source']['twitter']['image']

    newDict = {}
    for key, value in dictionary.items():
        newDict[key] = (value['Count'] * value['Score'])

    sortedTitle = sorted(newDict, key=newDict.get, reverse=True)

    return sortedTitle, dictionary


def main():
    strInput = raw_input("Enter the search query: ")
    sortedTitle, dictionary = check(strInput)

    print "\n\nThe Most Relevant Result:"
    print "Id: " + str(dictionary[sortedTitle[0]]['Id'])
    print "Title: " + sortedTitle[0]
    print "Score: " + str(dictionary[sortedTitle[0]]['Score'])
    print "URL: " + dictionary[sortedTitle[0]]['URL']
    print "Summary: " + dictionary[sortedTitle[0]]['Summary']
    print "Total matches: " + str(dictionary[sortedTitle[0]]['Count'])

    length = len(sortedTitle)
    if length > 10:
        length = 10
    elif length is 10:
        length = 9
    print "\n\nNext Relevant Results:\n"
    for i in range(1, length + 1):
        print "Result (" + str(i) + "):"
        print "Id: " + str(dictionary[sortedTitle[i]]['Id'])
        print "Title: " + sortedTitle[i]
        print "Score: " + str(dictionary[sortedTitle[i]]['Score'])
        print "URL: " + dictionary[sortedTitle[i]]['URL']
        print "Summary: " + dictionary[sortedTitle[i]]['Summary']
        print "Total matches: " + str(dictionary[sortedTitle[i]]['Count'])
        print "\n"


if __name__ == "__main__":
    main()
