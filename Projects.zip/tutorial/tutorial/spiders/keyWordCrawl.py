# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from tutorial.items import TutorialItem
from pymongo import MongoClient


class KeywordcrawlSpider(CrawlSpider):
    name = 'keyWordCrawl'
    allowed_domains = ['jagran.com']
    start_urls = ['http://www.jagran.com/search/news']

    rules = [
        Rule(LinkExtractor(allow='', restrict_xpaths=('//a[@class="next-btn"]')), follow=True),
        Rule(LinkExtractor(allow='', restrict_xpaths=('//ul[@class="listing"]/li/h3/a')), callback='parse_item', follow=True),
    ]

    def parse_item(self, response):
        keyWords = Selector(response).xpath('//meta[@itemprop="keywords"]/@content').extract()
        keyList = keyWords[0].split(',')
        client = MongoClient('localhost:27017')
        db = client.KeyWordsTest
        for key in keyList:
            item = TutorialItem()
            item['_id'] = key.strip()
            data = db.Contents.find({"_id": key.strip()})

            count = data.count()
            if count <= 0:
                item['count'] = 1
                count = 1
            else:
                item['count'] = data[0]['count'] + 1
                count = data[0]['count'] + 1
                db.Contents.update({'_id': key.strip()}, {'$set': {'count': count}}, upsert=True)

            item['itemList'] = {}
            item['itemList'][str(count)] = {}
            item['itemList'][str(count)]['url'] = Selector(response).xpath('//meta[@property="og:url"]/@content').extract()

            item['itemList'][str(count)]['data'] = {}

            alternateUrl = Selector(response).xpath('//link[@rel="alternate"]/@href')
            item['itemList'][str(count)]['data']['alternate_urls'] = alternateUrl[0].extract()

            item['itemList'][str(count)]['data']['author'] = Selector(response).xpath('//ul[@class="topsocial"]/li[@class="facebook"]/a/@href').extract()
            item['itemList'][str(count)]['data']['header_content_type'] = Selector(response).xpath('//meta[@http-equiv="Content-Type"]/@content').extract()

            item['itemList'][str(count)]['data']['source'] = {}
            item['itemList'][str(count)]['data']['source']['meta_description'] = Selector(response).xpath('//meta[@property="og:description"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['meta_keywords'] = Selector(response).xpath('//meta[@itemprop="keywords"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['meta_title'] = Selector(response).xpath('//meta[@property="og:title"]/@content').extract()

            # Older data set till here

            item['itemList'][str(count)]['data']['source']['body'] = Selector(response).xpath('//div[@class="article-content"]/p/text()').extract()
            item['itemList'][str(count)]['data']['source']['title'] = Selector(response).xpath('//section[@class="title"]/h1/text()').extract()
            item['itemList'][str(count)]['data']['source']['lastModified'] = Selector(response).xpath('//meta[@http-equiv="Last-Modified"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['summary'] = Selector(response).xpath('//div[@class="article-summery"]/text()').extract()

            item['itemList'][str(count)]['data']['source']['twitter'] = {}
            item['itemList'][str(count)]['data']['source']['twitter']['card'] = Selector(response).xpath('//meta[@name="twitter:card"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['twitter']['image'] = Selector(response).xpath('//meta[@name="twitter:image"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['twitter']['description'] = Selector(response).xpath('//meta[@name="twitter:description"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['twitter']['title'] = Selector(response).xpath('//meta[@name="twitter:title"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['twitter']['creator_id'] = Selector(response).xpath('//meta[@name="twitter:site"]/@content').extract()
            item['itemList'][str(count)]['data']['source']['twitter']['creator_username'] = Selector(response).xpath('//meta[@name="twitter:creator"]/@content').extract()

            yield item