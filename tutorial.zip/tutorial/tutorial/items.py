# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.item import Item, Field


class TutorialItem(scrapy.Item):
    # define the fields for your item here like:
    url = scrapy.Field() #Done
    alternate_urls = scrapy.Field() #Done
    data = scrapy.Field() #Done
    _source = scrapy.Field() #Done
    
    meta_keywords = scrapy.Field() #Done
    meta_description = scrapy.Field() #Done
    meta_title = scrapy.Field() #Done
    lastModified = scrapy.Field() #Done
    
    body = scrapy.Field() #Done
    title = scrapy.Field() #Done

    twitter = scrapy.Field() #Done
    card = scrapy.Field() #Done
    # tw_title = scrapy.Field() #Done
    image = scrapy.Field() #Done
    description = scrapy.Field() #Done
    creator_id = scrapy.Field() #Done
    creator_username = scrapy.Field() #Done
    
    author = scrapy.Field() #Done
    header_content_type = scrapy.Field() #Done
    
    summary = scrapy.Field() #Done
    # pass
