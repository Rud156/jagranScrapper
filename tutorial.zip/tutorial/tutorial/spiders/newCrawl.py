# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from tutorial.items import TutorialItem


class NewcrawlSpider(CrawlSpider):
    name = 'newCrawl'
    allowed_domains = ['jagran.com']
    start_urls = ['http://www.jagran.com/search/news'] # Reached page 99

    rules = [
        Rule(LinkExtractor(allow='', restrict_xpaths=('//a[@class="next-btn"]')), follow=True),
        Rule(LinkExtractor(allow='', restrict_xpaths=('//ul[@class="listing"]/li/h3/a')), callback='parse_item', follow=True),
    ]

    def parse_item(self, response):
        item = TutorialItem()

        itemList = Selector(response).xpath
        
        articleTitle = Selector(response).xpath('//section[@class="title"]/h1/text()').extract()
        mainImage = Selector(response).xpath('//div[@class="article-content"]/div/img/@src').extract()
        newsSummary = Selector(response).xpath('//div[@class="article-summery"]/text()').extract()
        newsContents = Selector(response).xpath('//div[@class="article-content"]/p/text()').extract()
        newsDate = Selector(response).xpath('//span[@class="date"]/text()').extract()

        
        item['summary'] = newsSummary
        item['title'] = articleTitle
        item['image'] = mainImage
        item['contents'] = newsContents
        item['date'] = newsDate

        yield item
