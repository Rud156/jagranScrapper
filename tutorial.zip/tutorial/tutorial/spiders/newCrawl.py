# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from tutorial.items import TutorialItem


class NewcrawlSpider(CrawlSpider):
    name = 'newCrawl'
    allowed_domains = ['jagran.com']
    start_urls = ['http://www.jagran.com/search/news'] # Reached page 101

    rules = [
        Rule(LinkExtractor(allow='', restrict_xpaths=('//a[@class="next-btn"]')), follow=True),
        Rule(LinkExtractor(allow='', restrict_xpaths=('//ul[@class="listing"]/li/h3/a')), callback='parse_item', follow=True),
    ]

    def parse_item(self, response):
        item = TutorialItem()


        itemList = Selector(response).xpath
    
        item['url'] = Selector(response).xpath('//meta[@property="og:url"]/@content').extract()

        item['data'] = {}

        alternateUrl = Selector(response).xpath('//link[@rel="alternate"]/@href')
        item['data']['alternate_urls'] = alternateUrl[1].extract()

        item['data']['author'] = Selector(response).xpath('//ul[@class="topsocial"]/li[@class="facebook"]/a/@href').extract()
        item['data']['header_content_type'] = Selector(response).xpath('//meta[@http-equiv="Content-Type"]/@content').extract()
        
        item['data']['source'] = {}
        item['data']['source']['meta_description'] = Selector(response).xpath('//meta[@property="og:description"]/@content').extract()
        item['data']['source']['meta_keywords'] = Selector(response).xpath('//meta[@itemprop="keywords"]/@content').extract()
        item['data']['source']['meta_title'] = Selector(response).xpath('//meta[@property="og:title"]/@content').extract()

        item['data']['source']['body'] = Selector(response).xpath('//div[@class="article-content"]/p/text()').extract()
        item['data']['source']['title'] = Selector(response).xpath('//section[@class="title"]/h1/text()').extract()
        item['data']['source']['lastModified'] = Selector(response).xpath('//meta[@http-equiv="Last-Modified"]/@content').extract()
        item['data']['source']['summary'] = Selector(response).xpath('//div[@class="article-summery"]/text()').extract()


        item['data']['source']['twitter'] = {}
        item['data']['source']['twitter']['card'] = Selector(response).xpath('//meta[@name="twitter:card"]/@content').extract()
        item['data']['source']['twitter']['image'] = Selector(response).xpath('//meta[@name="twitter:image"]/@content').extract()
        item['data']['source']['twitter']['description'] = Selector(response).xpath('//meta[@name="twitter:description"]/@content').extract()
        item['data']['source']['twitter']['tw_title'] = Selector(response).xpath('//meta[@name="twitter:title"]/@content').extract()
        item['data']['source']['twitter']['creator_id'] = Selector(response).xpath('//meta[@name="twitter:site"]/@content').extract()
        item['data']['source']['twitter']['creator_username'] = Selector(response).xpath('//meta[@name="twitter:creator"]/@content').extract()



        yield item
