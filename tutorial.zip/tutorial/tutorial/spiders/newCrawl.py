# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from tutorial.items import TutorialItem


class NewcrawlSpider(CrawlSpider):
    name = 'newCrawl'
    allowed_domains = ['jagran.com']
    start_urls = ['http://www.jagran.com/search/news']

    rules = (
        Rule(LinkExtractor(allow='', restrict_xpaths=('//a[@class="next-btn"]')), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        item = TutorialItem()
        
        articleTitle = Selector(response).xpath('//ul[@class="listing"]/li/h3/a/text()').extract()
        mainImage = Selector(response).xpath('//img[@class="imgTxt"]/@src').extract()
        newsSummary = Selector(response).xpath('//ul[@class="listing"]/li/p/text()').extract()

        
        item['summary'] = newsSummary
        item['title'] = articleTitle
        item['image'] = mainImage

        yield item
