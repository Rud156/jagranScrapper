# -*- coding: utf-8 -*-
from scrapy import Spider
from scrapy.selector import Selector

from tutorial.items import TutorialItem

class StackSpider(Spider):
    name = "stack"
    allowed_domains = ["www.jagran.com"]
    start_urls = ["http://www.jagran.com/search/news"]



    def parse(self, response):
        item = TutorialItem()

        articleTitle = Selector(response).xpath('//ul[@class="listing"]/li/h3/a/text()').extract()
        mainImage = Selector(response).xpath('//img[@class="imgTxt"]/@src').extract()
        newsSummary = Selector(response).xpath('//ul[@class="listing"]/li/p/text()').extract()

        
        item['summary'] = newsSummary
        item['title'] = articleTitle
        item['image'] = mainImage

        yield item
        
     
