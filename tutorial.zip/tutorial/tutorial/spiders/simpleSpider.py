from scrapy import Spider
from scrapy.selector import Selector

from tutorial.items import TutorialItem

class StackSpider(Spider):
    name = "stack"
    allowed_domains = ["www.jagran.com"]
    start_urls = ["http://www.jagran.com/search/news"]

    #rules = (Rule(SgmlLinkExtractor(allow=('pages/'), restrict_xpaths=('//li/a',)), callback = "parse", follow = True),)
    #rules = [Rule(LinkExtractor(allow=r'search\news-page[1-10]'), callback="parse", follow= True)]
    #rules = [Rule(LinkExtractor(allow=(), restrict_xpaths=('//a[@class="next-btn"]')), callback = "parse", follow= True)]


    def parse(self, response):
        item = TutorialItem()
        #newsSummary = Selector(response).xpath('//div[@class="article-content"]/div[@class="article-summery"]/text()').extract()
        #mainImage = Selector(response).xpath('//div[@class="article-content"]/div/img/@src').extract()
        #articleTitle = Selector(response).xpath('//section[@class="title"]/h1/text()').extract()

        articleTitle = Selector(response).xpath('//ul[@class="listing"]/li/h3/a/text()').extract()
        mainImage = Selector(response).xpath('//img[@class="imgTxt"]/@src').extract()
        newsSummary = Selector(response).xpath('//ul[@class="listing"]/li/p/text()').extract()

        
        item['summary'] = newsSummary
        item['title'] = articleTitle
        item['image'] = mainImage

        yield item
        
     
