from scrapy import Spider
from scrapy.selector import Selector
#import html2text

from tutorial.items import TutorialItem

class StackSpider(Spider):
    name = "stack"
    allowed_domains = ["www.jagran.com"]
    start_urls = ["http://www.jagran.com/news/national-pm-narendra-modi-to-hold-a-meeting-on-the-law-order-situation-in-jammu-and-kashmir-14302850.html?src=p2",]

    def parse(self, response):
        item = TutorialItem()
        newsSummary = Selector(response).xpath('//div[@class="article-content"]/div[@class="article-summery"]/text()').extract()
        mainImage = Selector(response).xpath('//div[@class="article-content"]/div/img/@src').extract()
        articleTitle = Selector(response).xpath('//section[@class="title"]/h1/text()').extract()

        item['summary'] = newsSummary
        item['title'] = articleTitle
        item['image'] = mainImage

        yield item
        
     
